<?php
// Heading
$_['heading_title'] = 'Refine Search';

// Text
$_['text_price']    = 'Price';
$_['text_category'] = 'Category';
