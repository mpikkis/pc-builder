<?php
// Heading
$_['heading_title']    = 'PC Builder Filter';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified PC Builder Filter module!';
$_['text_edit']        = 'Edit PC Builder Filter Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify PC Builder Filter module!';