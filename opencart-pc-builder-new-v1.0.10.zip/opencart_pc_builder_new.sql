-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 17, 2022 at 09:08 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `opencart_pc_builder_new`
--

-- --------------------------------------------------------

--
-- Table structure for table `pc_builder_build`
--

CREATE TABLE `oc_pc_builder_build` (
  `pc_builder_build_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `build` text NOT NULL,
  `code` varchar(16) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pc_builder_category`
--

CREATE TABLE `oc_pc_builder_category` (
  `pc_builder_category_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `sort_order` tinyint(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pc_builder_category_description`
--

CREATE TABLE `oc_pc_builder_category_description` (
  `pc_builder_category_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pc_builder_component`
--

CREATE TABLE `oc_pc_builder_component` (
  `pc_builder_component_id` int(11) NOT NULL,
  `pc_builder_category_id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `required` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `sort_order` tinyint(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pc_builder_component_category`
--

CREATE TABLE `oc_pc_builder_component_category` (
  `pc_builder_component_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pc_builder_component_description`
--

CREATE TABLE `oc_pc_builder_component_description` (
  `pc_builder_component_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pc_builder_incompatible_category`
--

CREATE TABLE `oc_pc_builder_incompatible_category` (
  `category_id` int(11) NOT NULL,
  `incompatible_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pc_builder_order`
--

CREATE TABLE `oc_pc_builder_order` (
  `pc_builder_order_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `build` text NOT NULL,
  `pc_builder_categories` text NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `weight` decimal(15,8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pc_builder_build`
--
ALTER TABLE `oc_pc_builder_build`
  ADD PRIMARY KEY (`pc_builder_build_id`);

--
-- Indexes for table `pc_builder_category`
--
ALTER TABLE `oc_pc_builder_category`
  ADD PRIMARY KEY (`pc_builder_category_id`) USING BTREE;

--
-- Indexes for table `pc_builder_category_description`
--
ALTER TABLE `oc_pc_builder_category_description`
  ADD PRIMARY KEY (`pc_builder_category_id`,`language_id`) USING BTREE;

--
-- Indexes for table `pc_builder_component`
--
ALTER TABLE `oc_pc_builder_component`
  ADD PRIMARY KEY (`pc_builder_component_id`) USING BTREE;

--
-- Indexes for table `pc_builder_component_category`
--
ALTER TABLE `oc_pc_builder_component_category`
  ADD PRIMARY KEY (`pc_builder_component_id`,`category_id`),
  ADD KEY `category_id` (`category_id`) USING BTREE;

--
-- Indexes for table `pc_builder_component_description`
--
ALTER TABLE `oc_pc_builder_component_description`
  ADD PRIMARY KEY (`pc_builder_component_id`,`language_id`) USING BTREE;

--
-- Indexes for table `pc_builder_incompatible_category`
--
ALTER TABLE `oc_pc_builder_incompatible_category`
  ADD PRIMARY KEY (`category_id`,`incompatible_id`),
  ADD KEY `incompatible_id` (`incompatible_id`);

--
-- Indexes for table `pc_builder_order`
--
ALTER TABLE `oc_pc_builder_order`
  ADD PRIMARY KEY (`pc_builder_order_id`),
  ADD KEY `order_id` (`order_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pc_builder_build`
--
ALTER TABLE `oc_pc_builder_build`
  MODIFY `pc_builder_build_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pc_builder_category`
--
ALTER TABLE `oc_pc_builder_category`
  MODIFY `pc_builder_category_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pc_builder_component`
--
ALTER TABLE `oc_pc_builder_component`
  MODIFY `pc_builder_component_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pc_builder_order`
--
ALTER TABLE `oc_pc_builder_order`
  MODIFY `pc_builder_order_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
