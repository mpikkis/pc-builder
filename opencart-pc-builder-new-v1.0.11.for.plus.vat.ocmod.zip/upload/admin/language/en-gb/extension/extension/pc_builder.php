<?php
// Heading
$_['heading_title']    = 'PC Builder';

// Column
$_['column_name']      = 'Menu';
$_['column_action']    = 'Action';

// Button
$_['button_manage']    = 'Manage';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify PC Builder!';