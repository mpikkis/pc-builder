<?php
// Heading
$_['heading_title']    = 'PC Builder Settings';

// Text
$_['text_success']     = 'Success: You have modified PC Builder Settings!';
$_['text_edit']        = 'Edit PC Builder Setting';

// Entry
$_['entry_filter']     = 'Filter';

// Error
$_['error_warning']    = 'Warning: Please check the form carefully for errors!';
$_['error_permission'] = 'Warning: You do not have permission to modify pc builder settings!';
